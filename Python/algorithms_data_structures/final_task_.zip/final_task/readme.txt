Ссылка на Google-документ со скриншотами заданий в Яндекс Контест, которые выполнял в течение спринта.
https://docs.google.com/document/d/1l2OS5xjAE1Szu8w7Xa_xossHFwh-YF7HLOkaynejUKo/edit?usp=sharing

Доступ открыт с ролью "Комментатор"



ID посылки решенной задачи из Яндекс-Контест: 116812845